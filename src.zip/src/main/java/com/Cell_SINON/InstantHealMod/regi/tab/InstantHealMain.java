package com.Cell_SINON.InstantHealMod.regi.tab;

import com.Cell_SINON.InstantHealMod.regi.InstantHealModItems;
import net.minecraft.world.item.InstrumentItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.alchemy.Potion;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModPotions;

public class InstantHealMain {

    public static final Item[] items = {
            InstantHealModItems.INSTANTRECOVERYAGENTS.get(),
            InstantHealModItems.HEROITEM.get(),


    };
    public static final Potion[] potions = {
            InstantHealModPotions.HEROPOTION.get()
    };
}