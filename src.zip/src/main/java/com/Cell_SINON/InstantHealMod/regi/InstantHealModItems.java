
package com.Cell_SINON.InstantHealMod.regi;

import com.Cell_SINON.InstantHealMod.item.Heroitem;
import com.Cell_SINON.InstantHealMod.item.ItemInstantRecoveryagents;
import com.Cell_SINON.InstantHealMod.main.InstantHealMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class InstantHealModItems {

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, InstantHealMod.MOD_id);

    public static final RegistryObject<Item> INSTANTRECOVERYAGENTS = ITEMS.register("instantrecoveryagents",
            () -> new ItemInstantRecoveryagents(new Item.Properties()
                    .stacksTo(20)));
    public static final RegistryObject<Item> HEROITEM = ITEMS.register("heroitem", ()->new Item(new Item.Properties().food(Heroitem.HEROITEM)));




    public static final String MOD_ID = "instanthealmod";




}