package com.Cell_SINON.InstantHealMod.main;
import com.Cell_SINON.InstantHealMod.regi.InstantHealModItems;
import com.Cell_SINON.InstantHealMod.regi.tab.InstantHealTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import java.util.logging.LogManager;
import net.minecraftforge.eventbus.api.SubscribeEvent;

@Mod("instanthealmod")
public class InstantHealMod {
    public static final String MOD_id = "instanthealmod";

    public static final DeferredRegister<Item> ITEM = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_id);
    public InstantHealMod() {

        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        InstantHealModItems.ITEMS.register(bus);
        InstantHealTabs.MOD_TABS.register(bus);
        
    }

}
